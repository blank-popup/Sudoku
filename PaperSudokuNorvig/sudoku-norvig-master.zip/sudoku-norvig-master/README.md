Sudoku solvers in Python, Clojure, Haskell, Ruby, etc. Based on Peter Norvig's constraint propagation and search algorithm.

[Peter Norvig's original essay](http://norvig.com/sudoku.html)

[Clojure version from Justin Kramer's inspiring blog](http://jkkramer.wordpress.com/2011/03/29/clojure-python-side-by-side/)

[Haskell version from Haskell Wiki by Manu](http://www.haskell.org/haskellwiki/Sudoku#Constraint_Propagation_.28a_la_Norvig.29)
